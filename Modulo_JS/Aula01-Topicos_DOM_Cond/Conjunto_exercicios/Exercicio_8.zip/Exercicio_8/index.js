if (number === 0 || number === 4 || number === 7) {
    alert("Parabéns, você acertou!");
} else {
    alert("Você não acertou");
}