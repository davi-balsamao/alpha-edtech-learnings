import Page from './components/Page.js';

document.querySelector("body").appendChild(Page());